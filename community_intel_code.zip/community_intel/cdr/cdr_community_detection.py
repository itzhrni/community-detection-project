"""
Module 1: CDR Community Detection
Dataset: Copenhagen Networks Study (calls/SMS)
Output: Community summaries → Neo4j
"""

import pandas as pd
import networkx as nx
import community as community_louvain  # pip install python-louvain
from collections import defaultdict
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# 1. LOAD COPENHAGEN CDR DATA
# ─────────────────────────────────────────────

def load_cdr(path: str) -> pd.DataFrame:
    """
    Copenhagen CDR CSV expected columns:
      caller_id, receiver_id, duration, timestamp, type (call/sms)

    Adjust column names below to match your actual file.
    """
    df = pd.read_csv(path)

    # Rename to standard names if needed — edit these to match your CSV headers
    df = df.rename(columns={
        "caller":   "caller_id",
        "callee":   "receiver_id",
        "duration": "duration",
        "time":     "timestamp",
        "type":     "type"
    })

    df = df.dropna(subset=["caller_id", "receiver_id"])
    df["duration"] = pd.to_numeric(df["duration"], errors="coerce").fillna(1)
    logger.info(f"Loaded {len(df)} CDR records")
    return df


# ─────────────────────────────────────────────
# 2. BUILD WEIGHTED COMMUNICATION GRAPH
# ─────────────────────────────────────────────

def build_graph(df: pd.DataFrame) -> nx.Graph:
    """
    Nodes = users (caller/receiver IDs)
    Edges = weighted by total call duration between pairs
    """
    G = nx.Graph()

    for _, row in df.iterrows():
        u = str(row["caller_id"])
        v = str(row["receiver_id"])
        w = float(row["duration"])

        w = max(w, 0.001)  # clip negatives — Louvain requires positive weights
        if G.has_edge(u, v):
            G[u][v]["weight"] += w
            G[u][v]["interactions"] += 1
        else:
            G.add_edge(u, v, weight=w, interactions=1)

    logger.info(f"Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    return G


# ─────────────────────────────────────────────
# 3. LOUVAIN COMMUNITY DETECTION
# ─────────────────────────────────────────────

def detect_communities(G: nx.Graph) -> dict:
    """
    Returns: {node_id: community_id}
    Uses weighted Louvain — higher weight = stronger community pull.
    """
    partition = community_louvain.best_partition(G, weight="weight", random_state=42)
    num_communities = len(set(partition.values()))
    logger.info(f"Detected {num_communities} communities")
    return partition


# ─────────────────────────────────────────────
# 4. EXTRACT COMMUNITY FEATURES
# ─────────────────────────────────────────────

def extract_features(G: nx.Graph, partition: dict, df: pd.DataFrame) -> list[dict]:
    """
    For each community, compute:
      - member list
      - size
      - density (internal edges / possible edges)
      - total call duration
      - total interactions
      - leader (highest degree centrality node)
      - bridge nodes (nodes connected to other communities)
    """
    # Group nodes by community
    communities = defaultdict(list)
    for node, comm_id in partition.items():
        communities[comm_id].append(node)

    # Pre-compute centrality on full graph
    degree_centrality = nx.degree_centrality(G)
    betweenness = nx.betweenness_centrality(G, weight="weight", normalized=True)

    results = []

    for comm_id, members in communities.items():
        subgraph = G.subgraph(members)

        # Density: fraction of edges present vs possible
        density = nx.density(subgraph)

        # Total calls and duration within community
        total_duration = sum(
            d["weight"] for _, _, d in subgraph.edges(data=True)
        )
        total_interactions = sum(
            d["interactions"] for _, _, d in subgraph.edges(data=True)
        )

        # Leader = highest degree centrality within subgraph
        leader = max(members, key=lambda n: degree_centrality.get(n, 0))

        # Bridge nodes = members connected to nodes outside this community
        bridges = []
        for node in members:
            neighbors = list(G.neighbors(node))
            external = [n for n in neighbors if partition.get(n) != comm_id]
            if external:
                bridges.append({
                    "node": node,
                    "external_connections": len(external),
                    "external_communities": list(set(partition.get(n) for n in external))
                })

        results.append({
            "community_id": int(comm_id),
            "members": members,
            "size": len(members),
            "density": round(density, 4),
            "total_call_duration_sec": round(total_duration, 2),
            "total_interactions": int(total_interactions),
            "leader": leader,
            "leader_centrality": round(degree_centrality.get(leader, 0), 4),
            "bridge_nodes": bridges,
            "avg_betweenness": round(
                sum(betweenness.get(m, 0) for m in members) / len(members), 4
            )
        })

    # Sort by size descending
    results.sort(key=lambda x: x["size"], reverse=True)
    logger.info(f"Extracted features for {len(results)} communities")
    return results


# ─────────────────────────────────────────────
# 5. MAIN PIPELINE
# ─────────────────────────────────────────────

def run_cdr_pipeline(cdr_path: str, output_json: str = "cdr_communities.json") -> list[dict]:
    df = load_cdr(cdr_path)
    G = build_graph(df)
    partition = detect_communities(G)
    communities = extract_features(G, partition, df)

    with open(output_json, "w") as f:
        json.dump(communities, f, indent=2)

    logger.info(f"Saved CDR communities → {output_json}")
    return communities


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "calls.csv"
    communities = run_cdr_pipeline(path)
    print(f"\nTop 3 communities by size:")
    for c in communities[:3]:
        print(f"  Community {c['community_id']}: {c['size']} members, "
              f"leader={c['leader']}, density={c['density']}")
