"""
Module 3: Neo4j Ingestion
Loads CDR + IPDR community data into Neo4j graph database.

Schema:
  (:CommunityCDR {id, size, density, leader, ...})
  (:CommunityIPDR {id, size, dominant_app, high_risk_ratio, ...})
  (:User {id}) -[:MEMBER_OF]-> (:CommunityCDR)
  (:IP {address}) -[:MEMBER_OF]-> (:CommunityIPDR)
  (:CommunityIPDR) -[:LINKED_TO {bridge_node}]-> (:CommunityIPDR)

Install:  pip install neo4j
Run Neo4j: docker run -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j
"""

from neo4j import GraphDatabase
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# CONNECTION
# ─────────────────────────────────────────────

class Neo4jConnection:
    def __init__(self, uri: str, user: str, password: str):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))
        logger.info("Connected to Neo4j")

    def close(self):
        self.driver.close()

    def run(self, query: str, params: dict = None):
        with self.driver.session() as session:
            return session.run(query, params or {})

    def run_many(self, query: str, batch: list[dict]):
        with self.driver.session() as session:
            session.run(query, {"batch": batch})


# ─────────────────────────────────────────────
# SCHEMA / CONSTRAINTS
# ─────────────────────────────────────────────

SCHEMA_QUERIES = [
    "CREATE CONSTRAINT IF NOT EXISTS FOR (c:CommunityCDR) REQUIRE c.id IS UNIQUE",
    "CREATE CONSTRAINT IF NOT EXISTS FOR (c:CommunityIPDR) REQUIRE c.id IS UNIQUE",
    "CREATE CONSTRAINT IF NOT EXISTS FOR (u:User) REQUIRE u.id IS UNIQUE",
    "CREATE CONSTRAINT IF NOT EXISTS FOR (ip:IP) REQUIRE ip.address IS UNIQUE",
    "CREATE INDEX IF NOT EXISTS FOR (c:CommunityCDR) ON (c.density)",
    "CREATE INDEX IF NOT EXISTS FOR (c:CommunityIPDR) ON (c.high_risk_ratio)",
]

def create_schema(conn: Neo4jConnection):
    for q in SCHEMA_QUERIES:
        conn.run(q)
    logger.info("Schema and constraints created")


# ─────────────────────────────────────────────
# INGEST CDR COMMUNITIES
# ─────────────────────────────────────────────

def ingest_cdr_communities(conn: Neo4jConnection, communities: list[dict]):
    """
    Creates CommunityCDR nodes, User nodes, MEMBER_OF edges,
    and BRIDGE_TO edges between communities.
    """
    # 1. Create community nodes
    comm_batch = []
    for c in communities:
        comm_batch.append({
            "id": c["community_id"],
            "size": c["size"],
            "density": c["density"],
            "leader": c["leader"],
            "leader_centrality": c["leader_centrality"],
            "total_call_duration_sec": c["total_call_duration_sec"],
            "total_interactions": c["total_interactions"],
            "avg_betweenness": c["avg_betweenness"]
        })

    conn.run("""
        UNWIND $batch AS row
        MERGE (c:CommunityCDR {id: row.id})
        SET c.size = row.size,
            c.density = row.density,
            c.leader = row.leader,
            c.leader_centrality = row.leader_centrality,
            c.total_call_duration_sec = row.total_call_duration_sec,
            c.total_interactions = row.total_interactions,
            c.avg_betweenness = row.avg_betweenness
    """, {"batch": comm_batch})

    # 2. Create User nodes and MEMBER_OF edges
    member_batch = []
    for c in communities:
        for user_id in c["members"]:
            member_batch.append({
                "user_id": str(user_id),
                "comm_id": c["community_id"],
                "is_leader": str(user_id) == str(c["leader"])
            })

    conn.run("""
        UNWIND $batch AS row
        MERGE (u:User {id: row.user_id})
        WITH u, row
        MATCH (c:CommunityCDR {id: row.comm_id})
        MERGE (u)-[r:MEMBER_OF]->(c)
        SET r.is_leader = row.is_leader
    """, {"batch": member_batch})

    # 3. Create BRIDGE_TO edges
    bridge_batch = []
    for c in communities:
        for bridge in c.get("bridge_nodes", []):
            for ext_comm in bridge.get("external_communities", []):
                if ext_comm is not None:
                    bridge_batch.append({
                        "from_comm": c["community_id"],
                        "to_comm": int(ext_comm),
                        "bridge_node": str(bridge["node"]),
                        "external_connections": bridge["external_connections"]
                    })

    if bridge_batch:
        conn.run("""
            UNWIND $batch AS row
            MATCH (c1:CommunityCDR {id: row.from_comm})
            MATCH (c2:CommunityCDR {id: row.to_comm})
            MERGE (c1)-[r:BRIDGE_TO]->(c2)
            SET r.bridge_node = row.bridge_node,
                r.strength = row.external_connections
        """, {"batch": bridge_batch})

    logger.info(f"Ingested {len(communities)} CDR communities, "
                f"{len(member_batch)} user-community relationships")


# ─────────────────────────────────────────────
# INGEST IPDR COMMUNITIES
# ─────────────────────────────────────────────

def ingest_ipdr_communities(conn: Neo4jConnection, communities: list[dict]):
    """
    Creates CommunityIPDR nodes, IP nodes, MEMBER_OF edges.
    """
    comm_batch = []
    for c in communities:
        app_profile = c.get("app_profile", {})
        comm_batch.append({
            "id": c["community_id"],
            "size": c["size"],
            "density": c["density"],
            "dominant_app": c["dominant_app"],
            "high_risk_ratio": c["high_risk_ratio"],
            "total_bytes": c["total_bytes"],
            "total_flow_count": c["total_flow_count"],
            "central_ip": c["central_ip"],
            "social_ratio": app_profile.get("categories", {}).get("social", 0),
            "streaming_ratio": app_profile.get("categories", {}).get("streaming", 0),
            "productivity_ratio": app_profile.get("categories", {}).get("productivity", 0),
            "top_apps": json.dumps(app_profile.get("top_apps", {}))
        })

    conn.run("""
        UNWIND $batch AS row
        MERGE (c:CommunityIPDR {id: row.id})
        SET c.size = row.size,
            c.density = row.density,
            c.dominant_app = row.dominant_app,
            c.high_risk_ratio = row.high_risk_ratio,
            c.total_bytes = row.total_bytes,
            c.total_flow_count = row.total_flow_count,
            c.central_ip = row.central_ip,
            c.social_ratio = row.social_ratio,
            c.streaming_ratio = row.streaming_ratio,
            c.productivity_ratio = row.productivity_ratio,
            c.top_apps = row.top_apps
    """, {"batch": comm_batch})

    # IP membership
    ip_batch = []
    for c in communities:
        for ip in c["ips"]:
            ip_batch.append({"address": str(ip), "comm_id": c["community_id"]})

    conn.run("""
        UNWIND $batch AS row
        MERGE (ip:IP {address: row.address})
        WITH ip, row
        MATCH (c:CommunityIPDR {id: row.comm_id})
        MERGE (ip)-[:MEMBER_OF]->(c)
    """, {"batch": ip_batch})

    logger.info(f"Ingested {len(communities)} IPDR communities, "
                f"{len(ip_batch)} IP-community relationships")


# ─────────────────────────────────────────────
# RISK SCORE UPDATE (called after risk scoring)
# ─────────────────────────────────────────────

def update_risk_scores(conn: Neo4jConnection, scores: list[dict], source: str = "CDR"):
    """
    scores: [{"community_id": int, "risk_score": float, "risk_label": str}]
    source: "CDR" or "IPDR"
    """
    label = f"Community{source}"
    batch = [{"id": s["community_id"],
               "risk_score": s["risk_score"],
               "risk_label": s.get("risk_label", "unknown")} for s in scores]

    conn.run(f"""
        UNWIND $batch AS row
        MATCH (c:{label} {{id: row.id}})
        SET c.risk_score = row.risk_score,
            c.risk_label = row.risk_label
    """, {"batch": batch})

    logger.info(f"Updated risk scores for {len(scores)} {source} communities")


# ─────────────────────────────────────────────
# RETRIEVAL QUERIES (used by RAG chatbot)
# ─────────────────────────────────────────────

RETRIEVAL_QUERIES = {

    "community_detail_cdr": """
        MATCH (c:CommunityCDR {id: $community_id})
        OPTIONAL MATCH (u:User)-[:MEMBER_OF]->(c)
        RETURN c, collect(u.id) AS members
    """,

    "community_detail_ipdr": """
        MATCH (c:CommunityIPDR {id: $community_id})
        RETURN c
    """,

    "high_risk_communities": """
        MATCH (c:CommunityCDR)
        WHERE c.risk_score IS NOT NULL
        RETURN c ORDER BY c.risk_score DESC LIMIT $limit
    """,

    "find_leader": """
        MATCH (c:CommunityCDR)
        WHERE c.leader = $user_id
        RETURN c
    """,

    "dominant_app_community": """
        MATCH (c:CommunityIPDR)
        WHERE toLower(c.dominant_app) = toLower($app_name)
        RETURN c ORDER BY c.total_flow_count DESC LIMIT $limit
    """,

    "bridges_between": """
        MATCH (c1:CommunityCDR)-[b:BRIDGE_TO]->(c2:CommunityCDR)
        RETURN c1.id AS from_community, c2.id AS to_community,
               b.bridge_node AS bridge_user, b.strength AS connections
        ORDER BY b.strength DESC LIMIT $limit
    """,

    "all_communities_summary": """
        MATCH (c:CommunityCDR)
        RETURN c.id AS id, c.size AS size, c.density AS density,
               c.leader AS leader, c.risk_score AS risk_score
        ORDER BY c.size DESC
    """,

    "top_youtube_communities": """
        MATCH (c:CommunityIPDR)
        WHERE c.dominant_app = 'youtube'
        RETURN c ORDER BY c.total_flow_count DESC LIMIT $limit
    """
}


def query_neo4j(conn: Neo4jConnection, query_name: str, params: dict = None) -> list[dict]:
    """Generic retrieval for RAG pipeline."""
    if query_name not in RETRIEVAL_QUERIES:
        raise ValueError(f"Unknown query: {query_name}")

    result = conn.run(RETRIEVAL_QUERIES[query_name], params or {})
    return [dict(record) for record in result]


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def ingest_all(
    cdr_json: str = "cdr_communities.json",
    ipdr_json: str = "ipdr_communities.json",
    neo4j_uri: str = "bolt://localhost:7687",
    neo4j_user: str = "neo4j",
    neo4j_password: str = "password"
):
    conn = Neo4jConnection(neo4j_uri, neo4j_user, neo4j_password)

    create_schema(conn)

    with open(cdr_json) as f:
        cdr_communities = json.load(f)
    ingest_cdr_communities(conn, cdr_communities)

    with open(ipdr_json) as f:
        ipdr_communities = json.load(f)
    ingest_ipdr_communities(conn, ipdr_communities)

    conn.close()
    logger.info("All data ingested into Neo4j ✓")


if __name__ == "__main__":
    ingest_all()
