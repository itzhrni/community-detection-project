"""
Module 4: Community Risk Scoring
Combines CDR + IPDR features to score each community.

Models used:
  - Isolation Forest (unsupervised anomaly detection)
  - Random Forest (if you have labelled data)
  - Rule-based fallback (always works without labels)

Output: risk_scores.json → fed back into Neo4j
"""

import json
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# 1. FEATURE ENGINEERING
# ─────────────────────────────────────────────

def build_cdr_feature_matrix(communities: list[dict]) -> pd.DataFrame:
    """
    Features from CDR communities:
      - size, density, total_interactions, total_call_duration_sec
      - leader_centrality, avg_betweenness
      - bridge_count (number of bridge nodes)
      - bridge_reach (total external community connections)
    """
    rows = []
    for c in communities:
        bridge_count = len(c.get("bridge_nodes", []))
        bridge_reach = sum(b.get("external_connections", 0) for b in c.get("bridge_nodes", []))

        rows.append({
            "community_id": c["community_id"],
            "size": c["size"],
            "density": c["density"],
            "total_interactions": c["total_interactions"],
            "total_call_duration_sec": c["total_call_duration_sec"],
            "leader_centrality": c["leader_centrality"],
            "avg_betweenness": c["avg_betweenness"],
            "bridge_count": bridge_count,
            "bridge_reach": bridge_reach,
            # Derived ratios
            "interactions_per_member": c["total_interactions"] / max(c["size"], 1),
            "duration_per_interaction": c["total_call_duration_sec"] / max(c["total_interactions"], 1)
        })

    df = pd.DataFrame(rows).set_index("community_id")
    return df


def build_ipdr_feature_matrix(communities: list[dict]) -> pd.DataFrame:
    """
    Features from IPDR communities:
      - size, density, total_flow_count, total_bytes
      - high_risk_ratio, social_ratio, streaming_ratio
      - bytes_per_flow, flows_per_ip
    """
    rows = []
    for c in communities:
        app_profile = c.get("app_profile", {})
        categories = app_profile.get("categories", {})

        rows.append({
            "community_id": c["community_id"],
            "size": c["size"],
            "density": c["density"],
            "total_flow_count": c["total_flow_count"],
            "total_bytes": c["total_bytes"],
            "high_risk_ratio": c["high_risk_ratio"],
            "social_ratio": categories.get("social", 0),
            "streaming_ratio": categories.get("streaming", 0),
            "productivity_ratio": categories.get("productivity", 0),
            # Derived
            "bytes_per_flow": c["total_bytes"] / max(c["total_flow_count"], 1),
            "flows_per_ip": c["total_flow_count"] / max(c["size"], 1)
        })

    df = pd.DataFrame(rows).set_index("community_id")
    return df


# ─────────────────────────────────────────────
# 2. ISOLATION FOREST (UNSUPERVISED)
# ─────────────────────────────────────────────

def isolation_forest_score(df: pd.DataFrame, contamination: float = 0.1) -> pd.Series:
    """
    Isolation Forest treats outliers (anomalies) as high-risk.
    Returns a risk score in [0, 1] — higher = more anomalous.
    contamination: expected fraction of anomalous communities (tune this).
    """
    features = df.select_dtypes(include=[np.number]).fillna(0)

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("iso_forest", IsolationForest(
            n_estimators=200,
            contamination=contamination,
            random_state=42,
            n_jobs=-1
        ))
    ])

    model.fit(features)

    # Raw scores are negative (more negative = more anomalous)
    raw_scores = model.named_steps["iso_forest"].score_samples(
        model.named_steps["scaler"].transform(features)
    )

    # Invert and normalise to [0, 1]
    inverted = -raw_scores
    min_s, max_s = inverted.min(), inverted.max()
    if max_s == min_s:
        normalised = pd.Series(0.5, index=df.index)
    else:
        normalised = pd.Series(
            (inverted - min_s) / (max_s - min_s),
            index=df.index
        )

    return normalised


# ─────────────────────────────────────────────
# 3. RULE-BASED SCORING (always available)
# ─────────────────────────────────────────────

def rule_based_cdr_score(row: pd.Series) -> float:
    """
    Heuristic risk score for CDR communities.
    Returns 0-1 float.
    """
    score = 0.0

    # High density + small size = tightly knit cell
    if row["density"] > 0.7 and row["size"] < 10:
        score += 0.3

    # High betweenness = information brokers / coordinators
    if row["avg_betweenness"] > 0.05:
        score += 0.2

    # Many bridge connections = cross-community coordination
    if row["bridge_count"] > 3:
        score += 0.2

    # Unusually high interactions per member
    if row["interactions_per_member"] > 50:
        score += 0.15

    # Very long average call duration (>10 min per call)
    if row["duration_per_interaction"] > 600:
        score += 0.15

    return min(score, 1.0)


def rule_based_ipdr_score(row: pd.Series) -> float:
    score = 0.0

    if row["high_risk_ratio"] > 0.3:
        score += 0.4

    if row["high_risk_ratio"] > 0.1:
        score += 0.2

    # Unusual bytes per flow (huge transfers or micro-packets)
    bytes_per_flow = row.get("bytes_per_flow", 0)
    if bytes_per_flow > 1_000_000 or (0 < bytes_per_flow < 50):
        score += 0.2

    # Very high flow density
    if row["flows_per_ip"] > 1000:
        score += 0.2

    return min(score, 1.0)


# ─────────────────────────────────────────────
# 4. COMBINED SCORING
# ─────────────────────────────────────────────

def label_risk(score: float) -> str:
    if score >= 0.75:
        return "HIGH"
    elif score >= 0.45:
        return "MEDIUM"
    else:
        return "LOW"


def score_cdr_communities(communities: list[dict], use_ml: bool = True) -> list[dict]:
    df = build_cdr_feature_matrix(communities)

    rule_scores = df.apply(rule_based_cdr_score, axis=1)

    if use_ml and len(df) >= 5:
        ml_scores = isolation_forest_score(df)
        # Blend: 60% ML + 40% rules
        final_scores = 0.6 * ml_scores + 0.4 * rule_scores
        logger.info("CDR: Using ML + rule blend")
    else:
        final_scores = rule_scores
        logger.info("CDR: Using rule-based scoring only")

    results = []
    for comm_id, score in final_scores.items():
        results.append({
            "community_id": int(comm_id),
            "risk_score": round(float(score), 4),
            "risk_label": label_risk(float(score)),
            "source": "CDR"
        })

    results.sort(key=lambda x: x["risk_score"], reverse=True)
    return results


def score_ipdr_communities(communities: list[dict], use_ml: bool = True) -> list[dict]:
    df = build_ipdr_feature_matrix(communities)

    rule_scores = df.apply(rule_based_ipdr_score, axis=1)

    if use_ml and len(df) >= 5:
        ml_scores = isolation_forest_score(df)
        final_scores = 0.6 * ml_scores + 0.4 * rule_scores
        logger.info("IPDR: Using ML + rule blend")
    else:
        final_scores = rule_scores
        logger.info("IPDR: Using rule-based scoring only")

    results = []
    for comm_id, score in final_scores.items():
        results.append({
            "community_id": int(comm_id),
            "risk_score": round(float(score), 4),
            "risk_label": label_risk(float(score)),
            "source": "IPDR"
        })

    results.sort(key=lambda x: x["risk_score"], reverse=True)
    return results


# ─────────────────────────────────────────────
# 5. MAIN
# ─────────────────────────────────────────────

def run_risk_pipeline(
    cdr_json: str = "cdr_communities.json",
    ipdr_json: str = "ipdr_communities.json",
    output_json: str = "risk_scores.json"
) -> dict:

    with open(cdr_json) as f:
        cdr_communities = json.load(f)

    with open(ipdr_json) as f:
        ipdr_communities = json.load(f)

    cdr_scores = score_cdr_communities(cdr_communities)
    ipdr_scores = score_ipdr_communities(ipdr_communities)

    all_scores = {"cdr": cdr_scores, "ipdr": ipdr_scores}

    with open(output_json, "w") as f:
        json.dump(all_scores, f, indent=2)

    logger.info(f"Risk scores saved → {output_json}")

    # Summary
    high_risk_cdr = [s for s in cdr_scores if s["risk_label"] == "HIGH"]
    high_risk_ipdr = [s for s in ipdr_scores if s["risk_label"] == "HIGH"]
    logger.info(f"CDR: {len(high_risk_cdr)} HIGH risk communities")
    logger.info(f"IPDR: {len(high_risk_ipdr)} HIGH risk communities")

    return all_scores


if __name__ == "__main__":
    scores = run_risk_pipeline()
    print("\nTop 5 HIGH-RISK CDR Communities:")
    for s in scores["cdr"][:5]:
        print(f"  Community {s['community_id']}: {s['risk_label']} ({s['risk_score']:.3f})")
    print("\nTop 5 HIGH-RISK IPDR Communities:")
    for s in scores["ipdr"][:5]:
        print(f"  Community {s['community_id']}: {s['risk_label']} ({s['risk_score']:.3f})")
