"""
Master Pipeline Runner
Runs all 4 modules in sequence:
  1. CDR community detection
  2. IPDR community detection
  3. Neo4j ingestion
  4. Risk scoring → Neo4j update

Usage:
  python run_pipeline.py --cdr calls.csv --ipdr flows.csv

Requirements:
  pip install pandas networkx python-louvain scikit-learn neo4j fastapi uvicorn ollama
  docker run -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password neo4j
"""

import argparse
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("pipeline")


def main():
    parser = argparse.ArgumentParser(description="Community Intelligence Pipeline")
    parser.add_argument("--cdr",      required=True,  help="Path to Copenhagen CDR CSV")
    parser.add_argument("--ipdr",     required=True,  help="Path to Kaggle 87-app IPDR CSV")
    parser.add_argument("--neo4j-uri",  default="bolt://localhost:7687")
    parser.add_argument("--neo4j-user", default="neo4j")
    parser.add_argument("--neo4j-pass", default="password")
    parser.add_argument("--skip-neo4j", action="store_true", help="Skip Neo4j ingestion (JSON only)")
    args = parser.parse_args()

    # ── Step 1: CDR ──────────────────────────────────────
    logger.info("=" * 50)
    logger.info("STEP 1: CDR Community Detection")
    logger.info("=" * 50)

    from cdr.cdr_community_detection import run_cdr_pipeline
    cdr_communities = run_cdr_pipeline(args.cdr, "cdr_communities.json")
    logger.info(f"Found {len(cdr_communities)} CDR communities")

    # ── Step 2: IPDR ─────────────────────────────────────
    logger.info("=" * 50)
    logger.info("STEP 2: IPDR Community Detection")
    logger.info("=" * 50)

    from ipdr.ipdr_community_detection import run_ipdr_pipeline
    ipdr_communities = run_ipdr_pipeline(args.ipdr, "ipdr_communities.json")
    logger.info(f"Found {len(ipdr_communities)} IPDR communities")

    # ── Step 3: Risk Scoring ──────────────────────────────
    logger.info("=" * 50)
    logger.info("STEP 3: Risk Scoring")
    logger.info("=" * 50)

    from risk.risk_scoring import run_risk_pipeline
    risk_scores = run_risk_pipeline("cdr_communities.json", "ipdr_communities.json", "risk_scores.json")

    high_cdr  = sum(1 for s in risk_scores["cdr"]  if s["risk_label"] == "HIGH")
    high_ipdr = sum(1 for s in risk_scores["ipdr"] if s["risk_label"] == "HIGH")
    logger.info(f"HIGH risk: {high_cdr} CDR communities, {high_ipdr} IPDR communities")

    # ── Step 4: Neo4j Ingestion ───────────────────────────
    if not args.skip_neo4j:
        logger.info("=" * 50)
        logger.info("STEP 4: Neo4j Ingestion")
        logger.info("=" * 50)

        from neo4j_module.neo4j_ingest import Neo4jConnection, create_schema
        from neo4j_module.neo4j_ingest import ingest_cdr_communities, ingest_ipdr_communities, update_risk_scores

        try:
            conn = Neo4jConnection(args.neo4j_uri, args.neo4j_user, args.neo4j_pass)
            create_schema(conn)
            ingest_cdr_communities(conn, cdr_communities)
            ingest_ipdr_communities(conn, ipdr_communities)
            update_risk_scores(conn, risk_scores["cdr"],  source="CDR")
            update_risk_scores(conn, risk_scores["ipdr"], source="IPDR")
            conn.close()
            logger.info("Neo4j ingestion complete ✓")
        except Exception as e:
            logger.error(f"Neo4j error: {e}")
            logger.info("Continuing without Neo4j — JSON files are still available.")

    # ── Done ─────────────────────────────────────────────
    logger.info("=" * 50)
    logger.info("PIPELINE COMPLETE")
    logger.info("=" * 50)
    logger.info("Output files:")
    logger.info("  cdr_communities.json")
    logger.info("  ipdr_communities.json")
    logger.info("  risk_scores.json")
    logger.info("")
    logger.info("To start the chatbot API:")
    logger.info("  cd chatbot && uvicorn chatbot:app --port 8000")


if __name__ == "__main__":
    main()
