"""
Module 5: RAG Chatbot
Analyst assistant for querying community intelligence.

Stack:
  - Retriever: Neo4j (structured graph queries)
  - LLM: Gemini 1.5 Flash via Google Generative AI
  - Interface: REST API (FastAPI) — consumed by the UI

Install:
  pip install fastapi uvicorn google-generativeai neo4j

Run this API:
  uvicorn chatbot:app --host 0.0.0.0 --port 8000
"""

import json
import re
import logging
from typing import Optional
import google.generativeai as genai
from neo4j import GraphDatabase
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# CONFIG — edit these
# ─────────────────────────────────────────────

NEO4J_URI      = "bolt://localhost:7687"
NEO4J_USER     = "neo4j"
NEO4J_PASSWORD = "password"

GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"   # ← paste your key here
GEMINI_MODEL   = "gemini-1.5-flash"            # or "gemini-1.5-pro"

genai.configure(api_key=GEMINI_API_KEY)
gemini_client = genai.GenerativeModel(
    model_name=GEMINI_MODEL,
    generation_config=genai.GenerationConfig(
        temperature=0.2,
        max_output_tokens=512,
    )
)


# ─────────────────────────────────────────────
# NEO4J RETRIEVER
# ─────────────────────────────────────────────

class CommunityRetriever:
    def __init__(self):
        self.driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

    def _run(self, query: str, params: dict = None) -> list[dict]:
        with self.driver.session() as session:
            result = session.run(query, params or {})
            return [dict(r) for r in result]

    def get_community_cdr(self, community_id: int) -> dict:
        rows = self._run("""
            MATCH (c:CommunityCDR {id: $id})
            OPTIONAL MATCH (u:User)-[r:MEMBER_OF]->(c)
            RETURN c,
                   collect({user: u.id, is_leader: r.is_leader}) AS members
        """, {"id": community_id})
        if not rows:
            return {}
        c = dict(rows[0]["c"])
        c["members"] = rows[0]["members"]
        return c

    def get_community_ipdr(self, community_id: int) -> dict:
        rows = self._run("""
            MATCH (c:CommunityIPDR {id: $id})
            RETURN c
        """, {"id": community_id})
        return dict(rows[0]["c"]) if rows else {}

    def get_high_risk(self, top_n: int = 5, source: str = "CDR") -> list[dict]:
        label = f"Community{source}"
        rows = self._run(f"""
            MATCH (c:{label})
            WHERE c.risk_score IS NOT NULL
            RETURN c ORDER BY c.risk_score DESC LIMIT $n
        """, {"n": top_n})
        return [dict(r["c"]) for r in rows]

    def get_dominant_app(self, app_name: str) -> list[dict]:
        rows = self._run("""
            MATCH (c:CommunityIPDR)
            WHERE toLower(c.dominant_app) CONTAINS toLower($app)
            RETURN c ORDER BY c.total_flow_count DESC LIMIT 5
        """, {"app": app_name})
        return [dict(r["c"]) for r in rows]

    def get_all_cdr_summary(self) -> list[dict]:
        rows = self._run("""
            MATCH (c:CommunityCDR)
            RETURN c.id AS id, c.size AS size, c.density AS density,
                   c.leader AS leader, c.risk_score AS risk_score,
                   c.total_interactions AS interactions
            ORDER BY c.size DESC
        """)
        return rows

    def get_bridges(self) -> list[dict]:
        rows = self._run("""
            MATCH (c1:CommunityCDR)-[b:BRIDGE_TO]->(c2:CommunityCDR)
            RETURN c1.id AS from_community, c2.id AS to_community,
                   b.bridge_node AS bridge_user, b.strength AS connections
            ORDER BY b.strength DESC LIMIT 10
        """)
        return rows

    def find_user_community(self, user_id: str) -> dict:
        rows = self._run("""
            MATCH (u:User {id: $uid})-[:MEMBER_OF]->(c:CommunityCDR)
            RETURN c
        """, {"uid": user_id})
        return dict(rows[0]["c"]) if rows else {}

    def stats_overview(self) -> dict:
        rows = self._run("""
            MATCH (c:CommunityCDR)
            RETURN count(c) AS total_cdr_communities,
                   avg(c.size) AS avg_size,
                   avg(c.density) AS avg_density,
                   avg(c.risk_score) AS avg_risk
        """)
        ipdr_rows = self._run("""
            MATCH (c:CommunityIPDR)
            RETURN count(c) AS total_ipdr_communities,
                   avg(c.high_risk_ratio) AS avg_high_risk_ratio
        """)
        result = dict(rows[0]) if rows else {}
        if ipdr_rows:
            result.update(dict(ipdr_rows[0]))
        return result


# ─────────────────────────────────────────────
# INTENT ROUTER
# ─────────────────────────────────────────────

def route_intent(question: str) -> tuple[str, dict]:
    """
    Lightweight regex-based intent router.
    Returns (intent_name, params).
    """
    q = question.lower()

    # Community detail
    m = re.search(r"community\s*(\d+)", q)
    if m:
        cid = int(m.group(1))
        if any(w in q for w in ["ipdr", "traffic", "app", "flow", "ip"]):
            return "community_ipdr", {"community_id": cid}
        return "community_cdr", {"community_id": cid}

    # Risk / suspicious
    if any(w in q for w in ["risk", "suspicious", "dangerous", "threat", "high risk"]):
        source = "IPDR" if any(w in q for w in ["ipdr", "traffic", "app"]) else "CDR"
        return "high_risk", {"source": source}

    # App queries
    for app in ["youtube", "tor", "facebook", "netflix", "whatsapp", "bittorrent",
                "instagram", "telegram", "twitter", "vpn", "spotify", "zoom"]:
        if app in q:
            return "dominant_app", {"app_name": app}

    # Bridge nodes
    if any(w in q for w in ["bridge", "bridges", "connector", "link"]):
        return "bridges", {}

    # User lookup
    m = re.search(r"user\s*(\w+)", q)
    if m:
        return "user_community", {"user_id": m.group(1)}

    # Overview / stats
    if any(w in q for w in ["overview", "summary", "stats", "total", "all communities", "how many"]):
        return "overview", {}

    # All communities list
    if any(w in q for w in ["list", "show all", "all cdr"]):
        return "all_cdr", {}

    return "unknown", {}


# ─────────────────────────────────────────────
# RETRIEVAL
# ─────────────────────────────────────────────

def retrieve(retriever: CommunityRetriever, intent: str, params: dict) -> str:
    """Fetch relevant data from Neo4j and return as formatted context string."""

    if intent == "community_cdr":
        data = retriever.get_community_cdr(params["community_id"])
        return json.dumps(data, indent=2) if data else f"Community {params['community_id']} not found in CDR data."

    elif intent == "community_ipdr":
        data = retriever.get_community_ipdr(params["community_id"])
        return json.dumps(data, indent=2) if data else f"Community {params['community_id']} not found in IPDR data."

    elif intent == "high_risk":
        data = retriever.get_high_risk(top_n=5, source=params.get("source", "CDR"))
        return json.dumps(data, indent=2) if data else "No risk scores found. Run the risk scoring pipeline first."

    elif intent == "dominant_app":
        data = retriever.get_dominant_app(params["app_name"])
        return json.dumps(data, indent=2) if data else f"No communities found with dominant app: {params['app_name']}"

    elif intent == "bridges":
        data = retriever.get_bridges()
        return json.dumps(data, indent=2) if data else "No bridge connections found."

    elif intent == "user_community":
        data = retriever.find_user_community(params["user_id"])
        return json.dumps(data, indent=2) if data else f"User {params['user_id']} not found."

    elif intent == "all_cdr":
        data = retriever.get_all_cdr_summary()
        return json.dumps(data, indent=2)

    elif intent == "overview":
        data = retriever.stats_overview()
        return json.dumps(data, indent=2)

    else:
        return "Could not determine specific data to retrieve. Please rephrase your question."


# ─────────────────────────────────────────────
# LLM PROMPT + GENERATION
# ─────────────────────────────────────────────

SYSTEM_PROMPT = """You are an intelligence analyst assistant for a network surveillance system.
You have access to community detection results from:
1. CDR data (call detail records) — social communities of phone users
2. IPDR data (internet flow records) — communities of IP addresses by traffic patterns

Given retrieved data from the graph database, answer analyst questions clearly and concisely.
Focus on:
- Key numbers (size, density, risk scores)
- Notable patterns (high risk communities, bridge nodes)
- Dominant applications in IP communities
- Leadership structure (central nodes, leaders)

Be direct and factual. If data is missing, say so. Do not hallucinate values.
Format: Short paragraph or bullet list. No preamble."""


def generate_answer(question: str, context: str) -> str:
    prompt = f"""{SYSTEM_PROMPT}

RETRIEVED DATA:
{context}

ANALYST QUESTION: {question}

ANSWER:"""

    response = gemini_client.generate_content(prompt)
    return response.text.strip()


# ─────────────────────────────────────────────
# FASTAPI APP
# ─────────────────────────────────────────────

app = FastAPI(title="Community Intelligence Chatbot", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

retriever = CommunityRetriever()


class QueryRequest(BaseModel):
    question: str
    include_raw_data: Optional[bool] = False


class QueryResponse(BaseModel):
    answer: str
    intent: str
    raw_data: Optional[str] = None


@app.post("/query", response_model=QueryResponse)
def query_endpoint(req: QueryRequest):
    intent, params = route_intent(req.question)
    logger.info(f"Intent: {intent}, Params: {params}")

    context = retrieve(retriever, intent, params)
    answer = generate_answer(req.question, context)

    return QueryResponse(
        answer=answer,
        intent=intent,
        raw_data=context if req.include_raw_data else None
    )


@app.get("/health")
def health():
    return {"status": "ok", "model": GEMINI_MODEL}


@app.get("/stats")
def stats():
    return retriever.stats_overview()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
