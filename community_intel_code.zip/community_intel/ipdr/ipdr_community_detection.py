"""
Module 2: IPDR Community Detection
Dataset: Kaggle 87 Network Applications (IPDR/flow data)
Output: IP community summaries with app profiles → Neo4j
"""

import pandas as pd
import networkx as nx
import community as community_louvain
from collections import defaultdict, Counter
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# KNOWN APP LABELS from Kaggle 87-app dataset
# ─────────────────────────────────────────────
# The dataset labels traffic by application name.
# These are grouped into risk tiers for scoring.

HIGH_RISK_APPS = {
    "tor", "i2p", "bittorrent", "vpn", "freenet",
    "emule", "aimini", "thunder", "xunlei"
}

SOCIAL_APPS = {
    "facebook", "twitter", "instagram", "snapchat",
    "whatsapp", "telegram", "wechat", "line", "viber"
}

STREAMING_APPS = {
    "youtube", "netflix", "twitch", "vimeo",
    "dailymotion", "spotify", "soundcloud"
}

PRODUCTIVITY_APPS = {
    "google", "gmail", "outlook", "skype",
    "zoom", "teams", "dropbox", "gdrive"
}


# ─────────────────────────────────────────────
# 1. LOAD KAGGLE IPDR DATA
# ─────────────────────────────────────────────

def load_ipdr(path: str) -> pd.DataFrame:
    """
    Kaggle 87-app dataset (dot-separated column names).
    """
    df = pd.read_csv(path)

    rename_map = {
        "Source.IP"                    : "src_ip",
        "Destination.IP"               : "dst_ip",
        "Source.Port"                  : "src_port",
        "Destination.Port"             : "dst_port",
        "Protocol"                     : "protocol",
        "Timestamp"                    : "timestamp",
        "Flow.Duration"                : "duration",
        "Total.Fwd.Packets"            : "fwd_packets",
        "Total.Backward.Packets"       : "bwd_packets",
        "Total.Length.of.Fwd.Packets"  : "fwd_bytes",
        "Total.Length.of.Bwd.Packets"  : "bwd_bytes",
        "Label"                        : "traffic_label",  # BENIGN/attack type
        "L7Protocol"                   : "l7_protocol",
        "ProtocolName"                 : "app_name",       # actual app: YouTube, Facebook etc.    }
    df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})

    # Combine fwd + bwd bytes into a single total
    if "fwd_bytes" in df.columns and "bwd_bytes" in df.columns:
        df["bytes_total"] = df["fwd_bytes"].fillna(0) + df["bwd_bytes"].fillna(0)
    elif "fwd_bytes" in df.columns:
        df["bytes_total"] = df["fwd_bytes"].fillna(0)
    else:
        df["bytes_total"] = 0

    # Normalize app names to lowercase
    if "app_name" in df.columns:
        df["app_name"] = df["app_name"].astype(str).str.lower().str.strip()

    df = df.dropna(subset=["src_ip", "dst_ip"])
    logger.info(f"Loaded {len(df)} IPDR flow records")
    logger.info(f"Unique apps: {df['app_name'].nunique() if 'app_name' in df.columns else 'N/A'}")
    return df


# ─────────────────────────────────────────────
# 2. BUILD IP FLOW GRAPH
# ─────────────────────────────────────────────

def build_flow_graph(df: pd.DataFrame) -> nx.DiGraph:
    """
    Directed graph: src_ip → dst_ip
    Edge attributes: flow count, bytes, dominant app
    """
    G = nx.DiGraph()

    for _, row in df.iterrows():
        src = str(row["src_ip"])
        dst = str(row["dst_ip"])
        app = str(row.get("app_name", "unknown"))
        bytes_val = float(row.get("bytes_total", 0))

        if G.has_edge(src, dst):
            G[src][dst]["flow_count"] += 1
            G[src][dst]["total_bytes"] += bytes_val
            G[src][dst]["apps"][app] = G[src][dst]["apps"].get(app, 0) + 1
        else:
            G.add_edge(src, dst,
                       flow_count=1,
                       total_bytes=bytes_val,
                       apps={app: 1})

    logger.info(f"Flow graph: {G.number_of_nodes()} IPs, {G.number_of_edges()} flows")
    return G


# ─────────────────────────────────────────────
# 3. CONVERT TO UNDIRECTED FOR LOUVAIN
# ─────────────────────────────────────────────

def to_undirected_weighted(G: nx.DiGraph) -> nx.Graph:
    """
    Louvain requires undirected graph.
    Merge bidirectional flows, weight = combined flow count.
    """
    UG = nx.Graph()
    for u, v, data in G.edges(data=True):
        if UG.has_edge(u, v):
            UG[u][v]["weight"] += data["flow_count"]
            UG[u][v]["total_bytes"] += data["total_bytes"]
            # Merge app counters
            for app, cnt in data["apps"].items():
                UG[u][v]["apps"][app] = UG[u][v]["apps"].get(app, 0) + cnt
        else:
            UG.add_edge(u, v,
                        weight=data["flow_count"],
                        total_bytes=data["total_bytes"],
                        apps=dict(data["apps"]))
    return UG


# ─────────────────────────────────────────────
# 4. COMMUNITY DETECTION
# ─────────────────────────────────────────────

def detect_ip_communities(G: nx.Graph) -> dict:
    partition = community_louvain.best_partition(G, weight="weight", random_state=42)
    logger.info(f"Detected {len(set(partition.values()))} IP communities")
    return partition


# ─────────────────────────────────────────────
# 5. APPLICATION PROFILING PER COMMUNITY
# ─────────────────────────────────────────────

def profile_apps(subgraph: nx.Graph) -> dict:
    """
    Aggregate all app traffic within a community subgraph.
    Returns breakdown by category and dominant app.
    """
    app_totals = Counter()

    for _, _, data in subgraph.edges(data=True):
        for app, cnt in data.get("apps", {}).items():
            app_totals[app] += cnt

    total_flows = sum(app_totals.values())
    if total_flows == 0:
        return {"dominant_app": "unknown", "categories": {}, "app_breakdown": {}}

    # Categorize
    category_flows = defaultdict(int)
    for app, cnt in app_totals.items():
        if app in HIGH_RISK_APPS:
            category_flows["high_risk"] += cnt
        elif app in SOCIAL_APPS:
            category_flows["social"] += cnt
        elif app in STREAMING_APPS:
            category_flows["streaming"] += cnt
        elif app in PRODUCTIVITY_APPS:
            category_flows["productivity"] += cnt
        else:
            category_flows["other"] += cnt

    dominant_app = app_totals.most_common(1)[0][0] if app_totals else "unknown"

    return {
        "dominant_app": dominant_app,
        "top_apps": dict(app_totals.most_common(5)),
        "categories": {k: round(v / total_flows, 4) for k, v in category_flows.items()},
        "high_risk_ratio": round(category_flows["high_risk"] / total_flows, 4),
        "total_app_flows": total_flows
    }


# ─────────────────────────────────────────────
# 6. EXTRACT COMMUNITY FEATURES
# ─────────────────────────────────────────────

def extract_ip_features(G: nx.Graph, partition: dict) -> list[dict]:
    communities = defaultdict(list)
    for node, comm_id in partition.items():
        communities[comm_id].append(node)

    degree_centrality = nx.degree_centrality(G)
    results = []

    for comm_id, members in communities.items():
        subgraph = G.subgraph(members)

        total_bytes = sum(
            d.get("total_bytes", 0) for _, _, d in subgraph.edges(data=True)
        )
        total_flows = sum(
            d.get("weight", 0) for _, _, d in subgraph.edges(data=True)
        )

        # Central IP (likely a hub/gateway)
        central_ip = max(members, key=lambda n: degree_centrality.get(n, 0))

        app_profile = profile_apps(subgraph)

        results.append({
            "community_id": int(comm_id),
            "ips": members,
            "size": len(members),
            "density": round(nx.density(subgraph), 4),
            "total_bytes": round(total_bytes, 2),
            "total_flow_count": int(total_flows),
            "central_ip": central_ip,
            "app_profile": app_profile,
            "dominant_app": app_profile["dominant_app"],
            "high_risk_ratio": app_profile["high_risk_ratio"]
        })

    results.sort(key=lambda x: x["total_flow_count"], reverse=True)
    logger.info(f"Extracted features for {len(results)} IP communities")
    return results


# ─────────────────────────────────────────────
# 7. MAIN PIPELINE
# ─────────────────────────────────────────────

def run_ipdr_pipeline(ipdr_path: str, output_json: str = "ipdr_communities.json") -> list[dict]:
    df = load_ipdr(ipdr_path)
    DG = build_flow_graph(df)
    G = to_undirected_weighted(DG)
    partition = detect_ip_communities(G)
    communities = extract_ip_features(G, partition)

    with open(output_json, "w") as f:
        json.dump(communities, f, indent=2)

    logger.info(f"Saved IPDR communities → {output_json}")
    return communities


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "flows.csv"
    communities = run_ipdr_pipeline(path)
    print(f"\nTop 3 communities by flow volume:")
    for c in communities[:3]:
        print(f"  Community {c['community_id']}: {c['size']} IPs, "
              f"dominant_app={c['dominant_app']}, "
              f"high_risk_ratio={c['high_risk_ratio']}")
